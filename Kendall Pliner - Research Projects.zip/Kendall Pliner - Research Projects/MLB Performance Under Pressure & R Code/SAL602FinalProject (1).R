library(baseballr)
library(tidyverse)
library(ggrepel)
library(plotly)

Regular_season_hitting <- read_csv("Downloads/MLB 2020-2025 Regular Season Hitting.csv")
Playoff_hitting <- read_csv("Downloads/Playoff Performances 2020-2025.csv")


regular_avg_BA <- Regular_season_hitting %>%
  filter(AB > 400) %>%
  group_by(Player) %>%
  summarise(
    avg_BA = mean(`BA▼`, na.rm = TRUE),
    seasons_played = n(),
    total_AB = sum(AB, na.rm = TRUE)
  ) %>%
  filter(seasons_played > 3) %>%   
  arrange(desc(avg_BA))

playoff_avg_BA <- Playoff_hitting %>%
  filter(AB > 6) %>%
  group_by(Player) %>%
  summarise(
    avg_BA = mean(`BA▼`, na.rm = TRUE),
    seasons_played = n(),
    total_AB = sum(AB, na.rm = TRUE)
  ) %>%
  arrange(desc(avg_BA))

combined_BA <- playoff_avg_BA %>%
  left_join(regular_avg_BA, by = "Player")

#Interactive Plot
plot_ly(
  data = combined_BA,
  x = ~avg_BA.x,
  y = ~avg_BA.y,
  type = "scatter",
  mode = "markers",
  text = ~paste(
    "Player:", Player, "<br>",
    "Regular BA:", round(avg_BA.x, 3), "<br>",
    "Playoff BA:", round(avg_BA.y, 3), "<br>",
    "Regular Seasons:", seasons_played.x, "<br>",
    "Playoff Seasons:", seasons_played.y,
    "Difference:", difference
  ),
  hoverinfo = "text",
  marker = list(size = 8, color = "cornflowerblue")
) %>% 
  layout(
    title = "Regular Season BA vs Playoff BA (Players 2020–2025)",
    xaxis = list(title = "Average Regular Season BA"),
    yaxis = list(title = "Average Playoff BA")
  )

final_dataset <- combined_BA %>%
  left_join(fangraphs_clean, by = "Player")

# Correlation between regular and playoff BA
cor_test <- cor.test(seasons_played.y,
                     final_dataset$avg_BA_playoff,
                     use = "complete.obs")
cor_test

# Linear regression model
model <- lm(avg_BA_playoff ~ seasons_played.y + FG_avg_wRCplus, data = final_dataset)
summary(model)

fg_list <- list()

for (year in 2020:2025) {
  message("Pulling FanGraphs data for ", year, " …")
  
  data_year <- tryCatch(
    {
      fg_batter_leaders(
        startseason = as.character(year),
        endseason = as.character(year),
        lg = "all",
        pos = "all",
        stats = "bat",
        qual = "0"
      )
    },
    error = function(e) {
      message("Failed to pull ", year)
      NULL
    }
  )
  
  fg_list[[as.character(year)]] <- data_year
}

fangraphs_all <- bind_rows(fg_list)

top_over <- final_dataset %>%
  arrange(desc(BA_difference)) %>%
  slice(1:10)

ggplot(top_over, aes(x = reorder(Player, BA_difference), y = BA_difference)) +
  geom_col(fill = "forestgreen") +
  coord_flip() +
  labs(
    title = "Top 10 Playoff Over-Performers (2020–2025)",
    x = "Player",
    y = "BA Difference"
  )
bottom_players <- final_dataset %>%
  arrange(BA_difference) %>%
  slice(1:10)
ggplot(bottom_players, aes(x = reorder(Player, BA_difference), y = BA_difference)) +
  geom_col(fill = "forestgreen") +
  coord_flip() +
  labs(
    title = "Top 10 Playoff Under-Performers (2020–2025)",
    x = "Player",
    y = "BA Difference"
  )